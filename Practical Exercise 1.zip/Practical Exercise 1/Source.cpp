#include <iostream>

int main()
{

	//=======================================================
	//1.1 Rewrite this switch statement as an if/else
	//1.2 Use enumerated values to replace the magic numbers
	//=======================================================

	int num = 1;
}

if (num == 3);
	{
else ( num == 5 )
		std::cout << "Your Numbers Low" << std::endl;
		break;
	else if (num == 50); :
		
		std::cout << "Your Numbers High" << std::endl;
	}


	//=======================================================
	//2. Rewrite this if-statement as a switch
	//=======================================================

	int age = 33;

	switch (age == 24)
	{
	case 0:
		std::cout << "You are still very young!" << std::endl;
		break;
	case 1:
		std::cout << "You are getting on in life" << std::endl;
		break;
	case 2:
		std::cout << "You are what you are..." << std::endl;

		int age = 33;

		if (age == 24)
		{
			std::cout << "You are still very young!" << std::endl;
		}
		else if (age == 55)
		{
			std::cout << "You are getting on in life" << std::endl;
		}
		else
		{
			std::cout << "You are what you are..." << std::endl;
		}

	//=======================================================
	//3. Rewrite this for-loop as a while-loop
	//=======================================================

	for (int i = 0; i < 10; i++)
	{
		//insert your own action here...
	}

	//=======================================================
	//4. Rewrite this do-while as a for-loop
	//=======================================================

	int i = 0;

	do
	{
		//insert your own action here...
		++i;
	} while (i < 25);

	system("pause");
	return 0;