#include <iostream>

int main() { // {} brackets open and close off groups of code to be kept together, ; closes off each line of code
	std::cout << "Hey guys!"; //Output can show crashes below to define and solve issues, syntax error is a form of grammar error, eg, typo error of a word or command
	std::cout << "Hows it going." << std::endl; // endl is endline for making code lines seperate, cout is the character output
	std::cout << "Are you enjoying c++." << std::endl;
	std::cout << "Putting endl allows a code to be seperated like a sentence." << std::endl;
	std::cout << "Given in this project example when the game runs." << std::endl; // Example of "stitched" code, code can just be continued on the same line
	std::cout << "Code can be stitched so to speak by continuing endl on the same line." << std::endl << "Just like in the example show here." << std::endl;
	std::cout << "Use '\n' to do what endl does, using wrong dash can add random data you dont want" << '\n' << "Just like this example next to this code" << std::endl; // '\n' is a short form of endl or another way of putting it

	std::cout << "Example Runs." << std::endl; // note, code cant be quoted within a current quote

		






}



