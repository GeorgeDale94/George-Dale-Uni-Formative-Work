#include <iostream>

int main() {


	std::cout << "Text of the Ultimate" << std::endl;
	std::cout << "" << std::endl;
	std::cout << "" << std::endl;
	std::cout << "" << std::endl;
    std::cout << "======New Game======" << std::endl;
	std::cout << "" << std::endl;
	std::cout << "-------Enter-------" << std::endl;
	std::cout << "" << std::endl;
	std::cout << "======End Game======"<< std::endl;
	std::cout << "" << std::endl;
	std::cout << "-------Escape-------" << std::endl;




}
	







